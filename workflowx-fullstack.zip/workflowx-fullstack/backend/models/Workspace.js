const mongoose = require("mongoose");

/*
  The whole WorkFlowX dashboard (employees, projects, tasks, bugs, teams,
  events, notifications, settings, etc.) is stored as ONE flexible JSON
  document per user. This mirrors the exact shape the frontend already
  keeps in localStorage ("state"), so no data-model translation is needed -
  whatever the frontend sends is what gets stored and returned.
*/
const workspaceSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, unique: true },
    data: { type: mongoose.Schema.Types.Mixed, required: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Workspace", workspaceSchema);
