require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const connectDB = require("./config/db");
const authRoutes = require("./routes/auth");
const workspaceRoutes = require("./routes/workspace");

const app = express();

app.use(cors());
app.use(express.json({ limit: "5mb" })); // dashboard state can be a fairly large JSON blob

app.use("/api/auth", authRoutes);
app.use("/api/workspace", workspaceRoutes);

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

// Serve the frontend (the WorkFlowX dashboard html/css/js) as static files
const frontendPath = path.join(__dirname, "..", "frontend");
app.use(express.static(frontendPath));
app.get("*", (req, res) => {
  res.sendFile(path.join(frontendPath, "workflowx.html"));
});

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => console.log(`WorkFlowX server running on port ${PORT}`));
});
