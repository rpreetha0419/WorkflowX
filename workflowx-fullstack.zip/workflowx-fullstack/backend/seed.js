/*
  Run once with: npm run seed
  Creates the demo admin account (from .env) if it doesn't already exist,
  so you can log in immediately after deploying.
*/
require("dotenv").config();
const bcrypt = require("bcryptjs");
const connectDB = require("./config/db");
const User = require("./models/User");
const mongoose = require("mongoose");

(async () => {
  await connectDB();
  const email = (process.env.DEMO_ADMIN_EMAIL || "admin@workflowx.com").toLowerCase();
  const password = process.env.DEMO_ADMIN_PASSWORD || "admin123";

  const existing = await User.findOne({ email });
  if (existing) {
    console.log(`Demo admin already exists: ${email}`);
  } else {
    const passwordHash = await bcrypt.hash(password, 10);
    await User.create({ name: "Admin User", email, passwordHash, role: "Administrator" });
    console.log(`Demo admin created: ${email} / ${password}`);
  }
  await mongoose.disconnect();
  process.exit(0);
})();
