const express = require("express");
const Workspace = require("../models/Workspace");
const requireAuth = require("../middleware/auth");

const router = express.Router();

// GET /api/workspace -> returns the saved dashboard data for this user (or null if none yet)
router.get("/", requireAuth, async (req, res) => {
  try {
    const ws = await Workspace.findOne({ user: req.userId });
    res.json({ data: ws ? ws.data : null, updatedAt: ws ? ws.updatedAt : null });
  } catch (err) {
    res.status(500).json({ message: "Failed to load workspace", error: err.message });
  }
});

// PUT /api/workspace -> overwrite the saved dashboard data for this user
router.put("/", requireAuth, async (req, res) => {
  try {
    const { data } = req.body;
    if (data === undefined) {
      return res.status(400).json({ message: "Missing 'data' in request body" });
    }
    const ws = await Workspace.findOneAndUpdate(
      { user: req.userId },
      { data },
      { upsert: true, new: true }
    );
    res.json({ message: "Saved", updatedAt: ws.updatedAt });
  } catch (err) {
    res.status(500).json({ message: "Failed to save workspace", error: err.message });
  }
});

module.exports = router;
