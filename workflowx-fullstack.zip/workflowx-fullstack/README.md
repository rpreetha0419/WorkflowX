# WorkFlowX — Full Stack (Frontend + Backend)

Your dashboard now has a real backend: login is checked against a database
instead of a hardcoded password, and all your data (employees, projects,
tasks, bugs, teams, events, notifications, AI settings) is saved to
MongoDB in the cloud — not just the browser's localStorage. It still works
offline with the old demo login if the backend is unreachable.

```
workflowx-fullstack/
├── backend/          Node.js + Express + MongoDB API
└── frontend/         Your WorkFlowX dashboard (workflowx.html)
```

## 1. Run it on your own laptop first (5 minutes)

### a) Create a free MongoDB Atlas database
1. Go to https://www.mongodb.com/cloud/atlas/register and make a free account.
2. Create a free "M0" cluster (any region).
3. Under **Database Access**, create a user with a username + password.
4. Under **Network Access**, click **Allow access from anywhere** (0.0.0.0/0) — fine for a college project.
5. Click **Connect → Drivers**, copy the connection string. It looks like:
   `mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/`

### b) Configure the backend
```bash
cd backend
cp .env.example .env
```
Open `.env` and paste your MongoDB connection string into `MONGO_URI`
(add `/workflowx` before the `?` so it saves into a database named
`workflowx`), and set `JWT_SECRET` to any random long string.

### c) Install and run
```bash
npm install
npm run seed     # creates the demo admin account (admin@workflowx.com / admin123)
npm start
```
You should see `MongoDB connected` and `WorkFlowX server running on port 5000`.

### d) Open the app
Visit **http://localhost:5000** in your browser (the backend also serves
the frontend for you). Log in with `admin@workflowx.com` / `admin123` —
this now goes through the real backend and your data will sync to MongoDB.

You can also open `frontend/workflowx.html` directly by double-clicking
it — it will detect the backend isn't reachable and fall back to the
original offline/localStorage demo mode automatically.

## 2. Deploy it for real (free)

### Step 1 — Push this folder to GitHub
Create a new GitHub repo and push the whole `workflowx-fullstack` folder to it.

### Step 2 — Deploy the backend on Render (free tier)
1. Go to https://render.com → New → Web Service → connect your GitHub repo.
2. **Root Directory:** `backend`
3. **Build Command:** `npm install`
4. **Start Command:** `npm start`
5. Add environment variables (same as your `.env` file): `MONGO_URI`, `JWT_SECRET`, `DEMO_ADMIN_EMAIL`, `DEMO_ADMIN_PASSWORD`.
6. Deploy. Render gives you a live URL like `https://workflowx-api.onrender.com`.
7. Open a Render **Shell** (or run once locally pointed at the same MONGO_URI) and run `npm run seed` so the demo admin account exists in production too.

Because `server.js` also serves the `frontend` folder as static files, this
one Render service hosts **both** your API and your dashboard — visiting
`https://workflowx-api.onrender.com` shows the full working app. Nothing
else to deploy.

*(Alternative to Render: Railway.app works the same way and is just as free for small projects.)*

### Step 3 — Share it
Send the Render URL to anyone — they can log in with the demo account or
register their own, and all data is safely stored in your MongoDB Atlas
database.

## 3. What talks to what

- `frontend/workflowx.html` — unchanged dashboard, plus a small API layer
  (`apiLogin`, `apiPullWorkspace`, `apiQueueSync`) near the top of the
  script that logs in against the backend and syncs the whole dashboard
  state to it automatically ~1 second after every change.
- `backend/routes/auth.js` — `/api/auth/login` and `/api/auth/register`
  check a hashed password in MongoDB and return a JWT token.
- `backend/routes/workspace.js` — `/api/workspace` (GET/PUT) reads and
  writes your entire dashboard data as one JSON document per user.
- `backend/models/` — Mongoose schemas for `User` and `Workspace`.

## 4. Notes for your project report / viva

- Auth: JWT-based, passwords hashed with bcrypt (never stored in plain text).
- Persistence: MongoDB Atlas (cloud NoSQL database), one document per user
  containing the full workspace — a pragmatic pattern for a dashboard-style
  app where the frontend already manages one unified state object.
- Resilience: frontend keeps a localStorage cache and falls back to
  offline demo mode if the API is unreachable, so the app is never fully broken.
- To extend further: split `Workspace.data` into proper collections
  (Employees, Projects, Tasks, Bugs...) with individual REST endpoints if
  you want fine-grained permissions per record later.
